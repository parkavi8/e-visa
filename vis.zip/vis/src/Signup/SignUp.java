package Signup;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class SignUp {

	private static JFrame frame;
	private JTextField txtName;
	private JTextField txtUsername;
	private JTextField txtEmail;
	private JPasswordField pwdPassword;

	/**
	 * Launch the application.
	 */	
			public void run() {
				try {
					SignUp.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}


	/**
	 * Create the application.
	 */
	public SignUp() {
		initialize();
	}

	public void abc(String user, String pass, String name, String email)  
	{	
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
				
			  try {
				String s = "insert into logindb values('"+user+"','"+pass+"','"+name+"','"+email+"')";
				Connection con= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","nayeem");
				Statement st = con.createStatement();
				ResultSet rs = st.executeQuery(s);
				
				//JOptionPane.showMessageDialog(null,"Record Entered","Success",JOptionPane.DEFAULT_OPTION);
				
				
				rs.close();
				st.close();
				con.close();	
				frame.setVisible(false);
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null,"Sign Up Failed: "+e,"Failed",JOptionPane.DEFAULT_OPTION);
				
			}	
	}
	
	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(204, 255, 255));
		frame.setBounds(100, 100, 605, 694);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setAlwaysOnTop(true);
		
		txtName = new JTextField();
		txtName.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				txtName.setText(null);
			}
		});
		
		pwdPassword = new JPasswordField();
		pwdPassword.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				pwdPassword.setText(null);
			}
		});
		pwdPassword.setText("PASSWORD");
		pwdPassword.setToolTipText("Password");
		pwdPassword.setHorizontalAlignment(SwingConstants.CENTER);
		pwdPassword.setBounds(116, 416, 312, 45);
		frame.getContentPane().add(pwdPassword);
		txtName.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtName.setForeground(Color.GRAY);
		txtName.setHorizontalAlignment(SwingConstants.CENTER);
		txtName.setText("NAME");
		txtName.setBounds(116, 152, 312, 45);
		frame.getContentPane().add(txtName);
		txtName.setColumns(10);
		
		txtUsername = new JTextField();
		txtUsername.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				txtUsername.setText(null);
			}
		});
		txtUsername.setForeground(Color.GRAY);
		txtUsername.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtUsername.setHorizontalAlignment(SwingConstants.CENTER);
		txtUsername.setText("USERNAME");
		txtUsername.setColumns(10);
		txtUsername.setBounds(116, 239, 312, 45);
		frame.getContentPane().add(txtUsername);
		
		txtEmail = new JTextField();
		txtEmail.setToolTipText("");
		txtEmail.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				txtEmail.setText(null);
			}
		});
		txtEmail.setText("EMAIL");
		txtEmail.setHorizontalAlignment(SwingConstants.CENTER);
		txtEmail.setForeground(Color.GRAY);
		txtEmail.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtEmail.setColumns(10);
		txtEmail.setBounds(116, 328, 312, 45);
		frame.getContentPane().add(txtEmail);
		
		JLabel lblSignUp = new JLabel("Create an Account");
		lblSignUp.setHorizontalAlignment(SwingConstants.CENTER);
		lblSignUp.setForeground(Color.BLUE);
		lblSignUp.setFont(new Font("Arial", Font.BOLD, 40));
		lblSignUp.setBounds(26, 59, 509, 56);
		frame.getContentPane().add(lblSignUp);
		
		JButton btnNewButton = new JButton("SIGN UP");
		btnNewButton.setForeground(new Color(0, 0, 0));
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("Arial", Font.BOLD, 19));
		btnNewButton.setBounds(205, 519, 156, 50);
		frame.getContentPane().add(btnNewButton);
		
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String name = txtName.getText();
				String username = txtUsername.getText();
				String email = txtEmail.getText();	
				@SuppressWarnings("deprecation")
				String password = pwdPassword.getText();
				
				abc(name,username,email,password);
			
			}
		});
	}
}
