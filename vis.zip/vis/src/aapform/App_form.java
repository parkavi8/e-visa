package aapform;


import java.awt.Color;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JCheckBox;

public class App_form extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField year1;
	private final JSeparator separator = new JSeparator();
	private final JSeparator separator_1 = new JSeparator();
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField year2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
			public static void run() {
				try {
					App_form frame = new App_form();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}


			public static void xyz(String nameFirst,String nameLast,String nationality,String d1,String m1,String y1,String email,String gender,String country,String passportNumber,String typeOfVisa,String d2,String m2,String y2)  
			{	
				try {
					Class.forName("oracle.jdbc.driver.OracleDriver");
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
						
					try {
						String s = "insert into visaform values('"+nameFirst+"','"+nameLast+"','"+d1+"','"+m1+"','"+y1+"','"+nationality+"','"+email+"','"+gender+"','"+country+"','"+passportNumber+"','"+d2+"','"+m2+"','"+y2+"','"+typeOfVisa+"')";
						Connection con= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","nayeem");
						Statement st = con.createStatement();
						ResultSet rs = st.executeQuery(s);
						
						JOptionPane.showMessageDialog(null,"Record Entered","Success",JOptionPane.DEFAULT_OPTION);
						
						rs.close();
						st.close();
						con.close();
									
						
					} catch (SQLException e) {
						
						System.out.println(e);
						JOptionPane.showMessageDialog(null,"record entered","sucess",JOptionPane.DEFAULT_OPTION);
					}
					
					
			}	
			
	/**
	 * Create the frame.
	 */
	public App_form() {
		setBackground(SystemColor.inactiveCaptionText);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1173, 1106);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblApplicationForml = new JLabel("APPLICATION FORM");
		lblApplicationForml.setForeground(new Color(0, 51, 255));
		lblApplicationForml.setFont(new Font("Book Antiqua", Font.BOLD, 45));
		lblApplicationForml.setBounds(300, 0, 620, 81);
		contentPane.add(lblApplicationForml);
		
		JLabel lblNewLabel = new JLabel("NAME:");
		lblNewLabel.setBackground(new Color(54, 215, 183));
		lblNewLabel.setFont(new Font("Calibri", Font.BOLD, 24));
		lblNewLabel.setBounds(15, 149, 98, 41);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 20));
		textField.setBounds(159, 147, 167, 41);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		textField_1.setBounds(380, 149, 167, 38);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNationality = new JLabel("NATIONALITY:");
		lblNationality.setFont(new Font("Calibri", Font.BOLD, 25));
		lblNationality.setBounds(674, 204, 155, 41);
		contentPane.add(lblNationality);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		textField_2.setBounds(869, 204, 195, 41);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("DATE OF BIRTH:");
		lblNewLabel_1.setFont(new Font("Calibri", Font.BOLD, 24));
		lblNewLabel_1.setBounds(15, 206, 167, 70);
		contentPane.add(lblNewLabel_1);
		
		year1 = new JTextField();
		year1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		year1.setBounds(460, 219, 98, 41);
		contentPane.add(year1);
		year1.setColumns(10);
		
		JLabel lblGender = new JLabel("GENDER:");
		lblGender.setFont(new Font("Calibri", Font.BOLD, 24));
		lblGender.setBounds(719, 271, 98, 41);
		contentPane.add(lblGender);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("Male");
		
		rdbtnNewRadioButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		rdbtnNewRadioButton.setBounds(731, 324, 98, 35);
		contentPane.add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("Female");
		rdbtnNewRadioButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					rdbtnNewRadioButton.setSelected(false);
			}
		});
		rdbtnNewRadioButton_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		rdbtnNewRadioButton_1.setBounds(861, 325, 104, 33);
		contentPane.add(rdbtnNewRadioButton_1);
		separator.setBounds(15, 84, 1121, 2);
		contentPane.add(separator);
		separator_1.setBounds(0, 390, 1215, 11);
		contentPane.add(separator_1);
		
		rdbtnNewRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
					rdbtnNewRadioButton_1.setSelected(false);
				
			}
		});
		
		JLabel lblPassportDetails = new JLabel("PASSPORT DETAILS");
		lblPassportDetails.setForeground(new Color(0, 0, 204));
		lblPassportDetails.setFont(new Font("Calibri", Font.BOLD, 28));
		lblPassportDetails.setBackground(new Color(0, 0, 255));
		lblPassportDetails.setBounds(0, 400, 275, 51);
		contentPane.add(lblPassportDetails);
		
		JLabel lblPassportNumber = new JLabel("PASSPORT NUMBER:");
		lblPassportNumber.setFont(new Font("Calibri", Font.BOLD, 24));
		lblPassportNumber.setBounds(63, 530, 237, 41);
		contentPane.add(lblPassportNumber);
		
		textField_6 = new JTextField();
		textField_6.setFont(new Font("Tahoma", Font.PLAIN, 20));
		textField_6.setBounds(333, 470, 326, 41);
		contentPane.add(textField_6);
		textField_6.setColumns(10);
		
		JLabel lblEmail = new JLabel("EMAIL:");
		lblEmail.setFont(new Font("Calibri", Font.BOLD, 24));
		lblEmail.setBounds(15, 292, 112, 41);
		contentPane.add(lblEmail);
		
		textField_7 = new JTextField();
		textField_7.setFont(new Font("Tahoma", Font.PLAIN, 20));
		textField_7.setBounds(148, 290, 399, 41);
		contentPane.add(textField_7);
		textField_7.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("COUNTRY OF PASSPORT:");
		lblNewLabel_2.setFont(new Font("Calibri", Font.BOLD, 24));
		lblNewLabel_2.setBounds(31, 467, 282, 51);
		contentPane.add(lblNewLabel_2);
		
		textField_8 = new JTextField();
		textField_8.setFont(new Font("Tahoma", Font.PLAIN, 20));
		textField_8.setBounds(343, 528, 275, 41);
		contentPane.add(textField_8);
		textField_8.setColumns(10);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(0, 606, 1215, 11);
		contentPane.add(separator_2);
		
		JLabel lblVisaDetails = new JLabel("VISA DETAILS:");
		lblVisaDetails.setForeground(new Color(0, 0, 204));
		lblVisaDetails.setFont(new Font("Calibri", Font.BOLD, 28));
		lblVisaDetails.setBackground(Color.BLUE);
		lblVisaDetails.setBounds(15, 617, 275, 51);
		contentPane.add(lblVisaDetails);
		
		JLabel lblPersonalDetails = new JLabel("PERSONAL DETAILS");
		lblPersonalDetails.setForeground(new Color(0, 0, 204));
		lblPersonalDetails.setFont(new Font("Calibri", Font.BOLD, 28));
		lblPersonalDetails.setBackground(Color.BLUE);
		lblPersonalDetails.setBounds(25, 93, 275, 51);
		contentPane.add(lblPersonalDetails);
		
		JLabel lblIntendedDateOf = new JLabel("INTENDED DATE OF ENTRY:");
		lblIntendedDateOf.setFont(new Font("Calibri", Font.BOLD, 24));
		lblIntendedDateOf.setBounds(15, 684, 282, 51);
		contentPane.add(lblIntendedDateOf);
		
		JLabel lblTypeOfVisa = new JLabel("TYPE OF VISA:");
		lblTypeOfVisa.setFont(new Font("Calibri", Font.BOLD, 24));
		lblTypeOfVisa.setBounds(43, 741, 282, 51);
		contentPane.add(lblTypeOfVisa);
		
		year2 = new JTextField();
		year2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		year2.setColumns(10);
		year2.setBounds(643, 687, 98, 41);
		contentPane.add(year2);
	
		
		JComboBox<String> month1 = new JComboBox<String>();
		month1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		month1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				month1.removeAllItems();
				month1.addItem("Jan");
				month1.addItem("Feb");
				month1.addItem("Mar");
				month1.addItem("Apr");
				month1.addItem("May");
				month1.addItem("Jun");
				month1.addItem("Jul");
				month1.addItem("Aug");
				month1.addItem("Sep");
				month1.addItem("Oct");
				month1.addItem("Nov");
				month1.addItem("Dec");
			}
		});
		month1.setBounds(333, 219, 112, 41);
		contentPane.add(month1);
		
		
		JComboBox<String> date1 = new JComboBox<String>();
		date1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		date1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				date1.removeAllItems();
				date1.addItem("1");
				date1.addItem("2");
				date1.addItem("3");
				date1.addItem("4");
				date1.addItem("5");
				date1.addItem("6");
				date1.addItem("7");
				date1.addItem("8");
				date1.addItem("9");
				date1.addItem("10");
				date1.addItem("11");
				date1.addItem("12");
				date1.addItem("13");
				date1.addItem("14");
				date1.addItem("15");
				date1.addItem("16");
				date1.addItem("17");
				date1.addItem("18");
				date1.addItem("19");
				date1.addItem("20");
				date1.addItem("21");
				date1.addItem("22");
				date1.addItem("23");
				date1.addItem("24");
				date1.addItem("25");
				date1.addItem("26");
				date1.addItem("27");
				date1.addItem("28");
				date1.addItem("29");
				date1.addItem("30");
				date1.addItem("31");
			}
		});
		date1.setBounds(197, 219, 104, 41);
		contentPane.add(date1);
		
		JComboBox<String> date2 = new JComboBox<String>();
		date2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		date2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				date2.removeAllItems();
				date2.addItem("1");
				date2.addItem("2");
				date2.addItem("3");
				date2.addItem("4");
				date2.addItem("5");
				date2.addItem("6");
				date2.addItem("7");
				date2.addItem("8");
				date2.addItem("9");
				date2.addItem("10");
				date2.addItem("11");
				date2.addItem("12");
				date2.addItem("13");
				date2.addItem("14");
				date2.addItem("15");
				date2.addItem("16");
				date2.addItem("17");
				date2.addItem("18");
				date2.addItem("19");
				date2.addItem("20");
				date2.addItem("21");
				date2.addItem("22");
				date2.addItem("23");
				date2.addItem("24");
				date2.addItem("25");
				date2.addItem("26");
				date2.addItem("27");
				date2.addItem("28");
				date2.addItem("29");
				date2.addItem("30");
				date2.addItem("31");
			}
		});
		date2.setBounds(333, 687, 104, 41);
		contentPane.add(date2);
		
		JComboBox<String> month2 = new JComboBox<String>();
		month2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		month2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				month2.removeAllItems();
				month2.addItem("Jan");
				month2.addItem("Feb");
				month2.addItem("Mar");
				month2.addItem("Apr");
				month2.addItem("May");
				month2.addItem("Jun");
				month2.addItem("Jul");
				month2.addItem("Aug");
				month2.addItem("Sep");
				month2.addItem("Oct");
				month2.addItem("Nov");
				month2.addItem("Dec");
			}
		});
		month2.setBounds(476, 687, 128, 41);
		contentPane.add(month2);
		
		JComboBox<String> comboBox_4 = new JComboBox<String>();
		comboBox_4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		comboBox_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				comboBox_4.removeAllItems();
				comboBox_4.addItem("Visitors Visa");
				comboBox_4.addItem("Student Visa");
				comboBox_4.addItem("Travel Visa");
				comboBox_4.addItem("Residential Visa");
				comboBox_4.addItem("Work Visa");
				
			}
		});
		comboBox_4.setBounds(333, 744, 267, 41);
		contentPane.add(comboBox_4);
		
		JButton btnNewButton = new JButton("SUBMIT");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String nameFirst = textField.getText();
				String nameLast = textField_1.getText();
				String nationality = textField_2.getText();
				String d1 = (String)(date1.getSelectedItem());
				String m1 = (String)(month1.getSelectedItem());
				String y1 = year1.getText();
				String email = textField_7.getText();
				String  gender = "Female";
				if(rdbtnNewRadioButton.isSelected())
				{
					gender = "Male";
				}
				else
				{
					gender = "Female";
				}
				
				
				
				String country = textField_6.getText();	
				String passportNumber = textField_8.getText();	
				
				String typeOfVisa = (String) comboBox_4.getSelectedItem();
				String d2 = (String) date2.getSelectedItem();
				String m2 = (String) month2.getSelectedItem();
				String y2 = year2.getText();
				
				xyz(nameFirst, nameLast, nationality, d1, m1, y1, email, gender,country, passportNumber, typeOfVisa, d2, m2, y2 );
			}	
		});
		
		btnNewButton.setFont(new Font("Calibri", Font.PLAIN, 26));
		btnNewButton.setForeground(new Color(0, 204, 0));
		btnNewButton.setBounds(380, 905, 195, 51);
		contentPane.add(btnNewButton);
		
		JCheckBox chckbxAllTheInformation = new JCheckBox("All the information mentioned above is true to my knowledge");
		chckbxAllTheInformation.setFont(new Font("Tahoma", Font.PLAIN, 20));
		chckbxAllTheInformation.setBounds(24, 817, 594, 29);
		contentPane.add(chckbxAllTheInformation);
		
		JLabel lblAttachTheRequired = new JLabel("ATTACH FILES:");
		lblAttachTheRequired.setFont(new Font("Calibri", Font.BOLD, 24));
		lblAttachTheRequired.setBounds(851, 684, 172, 70);
		contentPane.add(lblAttachTheRequired);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		textField_3.setBounds(839, 741, 255, 87);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		JButton btnBrowse = new JButton("BROWSE");
		btnBrowse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Desktop.getDesktop().open(new File("c:\\"));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		btnBrowse.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnBrowse.setBounds(979, 844, 115, 29);
		contentPane.add(btnBrowse);
	}
}
