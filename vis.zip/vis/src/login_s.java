

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import Signup.*;
import aapform.App_form;

public class login_s {

	private JFrame frame;
	private JTextField txtUsername;
	private JPasswordField txtPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login_s window = new login_s();
					window.frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public login_s() {
		initialize();
	}
	
	public static boolean loginCheck(String user, String pass)  
	{	
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
				
			try {
				String s = "Select * from logindb where username = '"+user+"' and password = '"+pass+"'";
				Connection con= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","nayeem");
				Statement st = con.createStatement();
				ResultSet rs = st.executeQuery(s);
				while(rs.next())
				{				
					return true;
				}
				rs.close();
				st.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return false;
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(204, 255, 255));
		frame.setAlwaysOnTop(true);
		frame.setBackground(new Color(0, 0, 255));
		frame.setBounds(300, 300, 888, 627);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblLoginSystem = new JLabel("Login :");
		lblLoginSystem.setForeground(Color.BLUE);
		lblLoginSystem.setFont(new Font("Arial", Font.BOLD, 40));
		lblLoginSystem.setBounds(101, 162, 188, 56);
		frame.getContentPane().add(lblLoginSystem);
		
		
		JLabel lblUsername = new JLabel("Username:");
		lblUsername.setFont(new Font("Arial", Font.PLAIN, 28));
		lblUsername.setBounds(101, 261, 163, 47);
		frame.getContentPane().add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setFont(new Font("Arial", Font.PLAIN, 28));
		lblPassword.setBounds(103, 337, 161, 44);
		frame.getContentPane().add(lblPassword);
		
		txtUsername = new JTextField();
		txtUsername.setFont(new Font("Tahoma", Font.PLAIN, 25));
		txtUsername.setBounds(339, 264, 285, 44);
		frame.getContentPane().add(txtUsername);
		txtUsername.setColumns(10);
		
		txtPassword = new JPasswordField();
		txtPassword.setFont(new Font("Tahoma", Font.PLAIN, 25));
		txtPassword.setBounds(339, 339, 286, 44);
		frame.getContentPane().add(txtPassword);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.setBackground(Color.LIGHT_GRAY);
		btnLogin.setForeground(Color.BLUE);
		btnLogin.setFont(new Font("Arial", Font.BOLD, 20));
		btnLogin.setBounds(452, 458, 149, 56);
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
								
				@SuppressWarnings("deprecation")
				String password = txtPassword.getText();
				String username = txtUsername.getText();
				
				if(loginCheck(username,password)) {
					txtUsername.setText(null);
					txtPassword.setText(null);
					frame.setVisible(false);
					App_form.run();
							
				}
				else {
					JOptionPane.showMessageDialog(null,"Invalid Details","Login Error",JOptionPane.ERROR_MESSAGE);
					txtUsername.setText(null);
					txtPassword.setText(null);
				}
				
								
			}
		});
		frame.getContentPane().add(btnLogin);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(0, 418, 851, 2);
		frame.getContentPane().add(separator);
		
		JButton buttonSignUp = new JButton("Sign Up");		buttonSignUp.setForeground(Color.BLUE);
		buttonSignUp.setBackground(Color.LIGHT_GRAY);
		buttonSignUp.setFont(new Font("Arial", Font.BOLD, 20));
		buttonSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				SignUp su = new SignUp();
				su.run();
				
			}
		});
		buttonSignUp.setBounds(173, 458, 139, 56);
		frame.getContentPane().add(buttonSignUp);
		
		JLabel lblOnlineVisaServices = new JLabel("E-VISA SERVICE");
		lblOnlineVisaServices.setFont(new Font("Arial", Font.BOLD, 45));
		lblOnlineVisaServices.setBounds(219, 66, 632, 47);
		frame.getContentPane().add(lblOnlineVisaServices);
	}
}
